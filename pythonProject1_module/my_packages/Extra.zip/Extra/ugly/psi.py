def funP():
    return "Psi"


if __name__ == "__main__":
    print("I prefer to be a module")
    print(funP() == "Psi")
